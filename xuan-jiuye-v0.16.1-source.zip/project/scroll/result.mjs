import { getPalaceReading, readingFact, palaceTitle, READING_TOPICS } from './chart.mjs';
import { bookFromChart } from './book.mjs';

export function resultFromChart(chart, subject) {
  const book = bookFromChart(chart);
  const readings = chart.palaces.map(p => getPalaceReading(chart, p.name));
  if (readings.length !== 12 || readings.some(r => !r)) throw new Error('十二宮資料未能核對，請返回出生資料。');
  return { book, readings, selected: book.chapters.find(c => c.label === subject)?.key || '命宮' };
}

export function attachResult(report) {
  const find = id => report.querySelector('#' + id);
  const textNode = (tag, value, cls) => {
    const node = document.createElement(tag); node.textContent = value;
    if (cls) node.className = cls;
    return node;
  };
  const put = (id, value) => { find(id).textContent = value; };
  const positions = { 寅:[4,1], 卯:[3,1], 辰:[2,1], 巳:[1,1], 午:[1,2], 未:[1,3], 申:[1,4], 酉:[2,4], 戌:[3,4], 亥:[4,4], 子:[4,3], 丑:[4,2] };
  let current = null, name = '', canOffer = false;
  const prices = { full: [388, 240, 148], single: [228, 140, 88] };

  function pricing(key) {
    const [original, discount, total] = prices[key];
    put('price-original', 'HK$' + original);
    put('price-discount', '-HK$' + discount);
    for (const id of ['price-final', 'cta-price', 'purchase-price']) put(id, 'HK$' + total);
    put('purchase-plan', key === 'full' ? '全盤深層命書' : '單一話題拆局書');
    for (const plan of ['full', 'single']) find('sku-' + plan).setAttribute('aria-pressed', String(plan === key));
  }
  for (const key of ['full', 'single']) find('sku-' + key).addEventListener('click', () => {
    if (current && canOffer) pricing(key);
  });
  find('purchase-cta').addEventListener('click', () => {
    if (current && canOffer) find('purchase-dialog').showModal();
  });
  find('close-purchase').addEventListener('click', () => find('purchase-dialog').close());

  function topic(key) {
    const chapter = current?.book.chapters.find(c => c.key === key);
    if (!chapter) return;
    find('topic-select').value = key;
    put('pattern-badge', current.book.element + ' · ' + chapter.source);
    put('empathy-headline', name + '，由' + chapter.label + '開始，一件一件慢慢拆。');
    find('empathy-body').replaceChildren(...[chapter.lens, chapter.people, chapter.other].filter(Boolean).map(v => textNode('p', v)));
    put('jiuye-quote', READING_TOPICS[key].question);
    put('basis-detail', chapter.fact + (chapter.borrow ? ' 借星仍然喺對宮，唔會搬入本宮。' : ' 呢度讀嘅係本宮主星。') + '星曜係文化象徵，近況由你自己對照。');
    find('basis').open = false;
    find('resonance').setAttribute('aria-pressed', 'false');
    put('resonance', '呢句講中咗 ✦');
    palace(key);
  }
  function palace(key) {
    const reading = current?.readings.find(r => r.palace === key);
    if (!reading) return;
    for (const button of find('result-grid').querySelectorAll('button')) button.setAttribute('aria-pressed', String(button.dataset.palace === key));
    const note = find('palace-detail');
    note.replaceChildren(textNode('h3', '玄 · ' + palaceTitle(key)), textNode('p', readingFact(reading), 'source'), textNode('p', reading.lead));
    for (const star of reading.opposite ? reading.opposite.stars : reading.stars) {
      note.append(textNode('h4', star.name + ' · ' + star.theme), textNode('p', star.behaviour));
    }
    note.append(textNode('p', '九爺：' + reading.question, 'jade-copy'));
  }
  find('topic-select').addEventListener('change', event => topic(event.target.value));
  find('resonance').addEventListener('click', () => {
    if (!current) return;
    const pressed = find('resonance').getAttribute('aria-pressed') !== 'true';
    find('resonance').setAttribute('aria-pressed', String(pressed));
    put('resonance', pressed ? '留低呢句，再慢慢諗 ✦' : '呢句講中咗 ✦');
  });
  return {
    show({ chart, alias, subject, offer = true }) {
      current = resultFromChart(chart, subject); name = alias;
      canOffer = offer;
      find('purchase-cta').hidden = !canOffer;
      pricing('full');
      for (const node of report.querySelectorAll('.js-user-name')) node.textContent = alias;
      topic(current.selected);
      const grid = find('result-grid'); grid.replaceChildren();
      for (const p of chart.palaces) {
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'palace-cell'; button.dataset.palace = p.name;
        [button.style.gridRow, button.style.gridColumn] = positions[p.earthlyBranch];
        button.append(textNode('strong', palaceTitle(p.name)), textNode('span', p.heavenlyStem + p.earthlyBranch + (p.isBodyPalace ? ' · 身宮' : '')));
        const stars = p.majorStars.filter(s => s.type === 'major');
        button.append(textNode('span', stars.map(s => s.name + (s.mutagen ? '化' + s.mutagen : '')).join('、') || '本宮無十四主星', 'gold-copy'));
        button.setAttribute('aria-label', '睇' + palaceTitle(p.name) + '，' + p.earthlyBranch + '位');
        button.addEventListener('click', () => palace(p.name)); grid.append(button);
      }
      const center = textNode('div', '', 'palace-center');
      center.append(textNode('strong', '紫微斗數'), textNode('span', current.book.element), textNode('span', '本命十二宮'), textNode('small', '按所填當地時間\n未校真太陽時'));
      grid.append(center); palace(current.selected);
      find('chart-details').open = find('topic-menu').open = false;
    },
    clear() {
      if (find('purchase-dialog').open) find('purchase-dialog').close();
      current = null; name = ''; canOffer = false;
      find('purchase-cta').hidden = true;
      pricing('full');
      for (const id of ['pattern-badge', 'empathy-headline', 'empathy-body', 'jiuye-quote', 'basis-detail', 'result-grid', 'palace-detail']) find(id).replaceChildren();
      for (const node of report.querySelectorAll('.js-user-name')) node.textContent = '';
      find('basis').open = find('chart-details').open = find('topic-menu').open = false;
      find('topic-select').value = '命宮';
      find('resonance').setAttribute('aria-pressed', 'false'); put('resonance', '呢句講中咗 ✦');
    }
  };
}
